<div class="maps-margin-top">
    <div class="text-center crops-margin mb-3 wow fadeInUp">
        <div class="d-flex justify-content-center align-items-center custom-gap-newsletter">
            <div>
                <img src="{{ asset('/web/img/loader 2.png') }}" alt="" class="img-fluid">
            </div>
            <div>
                <img src="{{ asset('/web/img/loader 2.png') }}" alt="" class="img-fluid">
            </div>
        </div>
        <h3 class="text-success fw-bold pb-2">LOCAL DISTRIBUTION</h3>
        <video data-src="{{ asset('uploads/setting/' . $setting->map_path) }}" autoplay muted loop class="w-100 h-100"
            style="object-fit: cover;" data-lazy="true">
        </video>

    </div>
</div>
