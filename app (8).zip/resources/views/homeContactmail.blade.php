<div class="contact-email">
    Name:{{ $name }} <br>
    Email:{{ $email }} <br>
    Phone:{{ $phone }} <br>
    Address:{{ $subject }} <br>
    service:{{ $message_content }}
</div>
